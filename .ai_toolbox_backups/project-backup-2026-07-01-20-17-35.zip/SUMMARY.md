# Project Summary — AI Toolbox Plugin v1.5.x

Comprehensive overview of the AI Toolbox plugin, its architecture, features, and recent changes. This document provides a high-level summary for developers, maintainers, and users.

---

## 📋 Table of Contents

- [Project Overview](#project-overview)
- [Key Features](#key-features)
- [Architecture Summary](#architecture-summary)
- [Recent Changes (v1.5.x)](#recent-changes-v15x)
- [Security Posture](#security-posture)
- [Performance Characteristics](#performance-characteristics)
- [Development Status](#development-status)

---

## 🎯 Project Overview

**AI Toolbox Plugin** is a comprehensive LM Studio plugin providing **110 tools across 20 categories** for AI-assisted development workflows. The plugin enables language models to interact with file systems, execute code, browse the web, manage Git repositories, process documents, and more — all within a secure, configurable framework.

### Core Capabilities

| Category | Tool Count | Purpose |
|----------|------------|---------|
| File System | 21 tools | Read, write, search, and manage files with path validation |
| Web Research | 4 tools | Multi-engine search (DDG, Google, Bing) with automatic fallback |
| Browser Automation | 5 tools | Headless Puppeteer browser with persistent sessions |
| Git & GitHub | 13 tools | Full Git operations + GitHub API integration |
| Database | 1 tool | Read-only SQLite queries with SQL validation |
| Document Parsing | 1 tool | PDF, DOCX, TXT document reading (disk paths + attachments) |
| Background Commands | 3 tools | Long-running process management with timeout control |
| Execution | 5 tools | Sandboxed JS/Python + full shell commands (pipes, redirects) |
| Utilities | 24 tools | Clipboard, notifications, system info, memory, session summaries, JSON query, env management |
| Image Processing | 4 tools | OCR (Tesseract.js), screenshots (Win32 API), image comparison |
| HTTP Client | 3 tools | REST API client with SSRF protection |
| Vector RAG | 4 tools | Semantic search with local embeddings, persistent state |
| Text Processing | 3 tools | Regex substitutions (`text_transform`), field extraction (`text_extract`) |
| Interactive UI Generation | 3 tools | Generate and render HTML/CSS/JS components (buttons, forms, charts) |
| Auto-Context Management | 7 tools | Automatic session tracking, decision logging, persistent memory |
| Backup & Restore | 4 tools | Create compressed ZIP backups with atomic write pattern |

**Total:** 110 tools across 20 categories ✅

---

## ✨ Key Features

### 🔒 Security-First Design

All tools implement security controls by default:
- **Path validation** prevents directory traversal attacks
- **Command sanitization** blocks dangerous shell patterns
- **Category gating** disables dangerous tools until explicitly enabled
- **Size limits** prevent resource exhaustion (10MB file writes, 50KB web fetches)

### ⚡ Async Architecture

All I/O operations use async/await to avoid blocking the event loop:
- File system operations → `fs.promises`
- Database queries → Node.js SQLite (async)
- Browser automation → Puppeteer (async APIs)
- HTTP requests → Native fetch with timeouts

### 🧠 Context Management

Automatic session tracking and memory persistence:
- **Auto-tracking enabled by default** — tracks decisions, completions, bug fixes
- **Token threshold auto-save** — saves context when usage reaches 75% of limit
- **Persistent storage** — `.ai_toolbox_context.msgpack` for compact binary format

### 📊 Configuration Flexibility

Comprehensive configuration via Zod schemas:
- Individual tool categories toggleable on/off
- Execution tools disabled by default (require explicit opt-in)
- ContextGuard settings for token management and history compression
- Search fallback chain (DDG API → DDG Fetch → Google → Bing)

---

## 🏗️ Architecture Summary

### System Flow

```
LM Studio Host
    │
    ▼
Plugin Runner (Node.js 20+)
    │
    ├── Config Layer (Zod schemas + UI schematics)
    ├── Security Layer (Path validation, command sanitization, SQL guards)
    ├── State Management (Debounced persistence to JSON/msgpack files)
    └── Tool Registry (20 modules → 108 tools total)
```

### Core Modules

| Module | Purpose | Key Features |
|--------|---------|--------------|
| `config.ts` | Configuration schema + UI toggles | Zod validation, default values, category gating |
| `security.ts` | Input validation & sanitization | Path traversal prevention, command pattern blocking |
| `stateManager.ts` | Persistent state with debounced writes | Atomic file operations, corruption recovery |
| `toolsProvider.ts` | Central tool registration | Config-based filtering, God Mode bypass |
| `promptPreprocessor.ts` | Document RAG + ContextGuard integration | History compression, temporal awareness injection |

### Tool Categories (16 modules)

Each category is implemented as a separate module in `src/tools/`:
- `fileSystemTools.ts` — 20 file system tools
- `webResearchTools.ts` — 4 web research tools
- `browserAutomationTools.ts` — 5 browser automation tools
- `gitGithubTools.ts` — 13 Git/GitHub tools (6 git + 7 GitHub API)
- `databaseTools.ts` — 1 database tool (SQLite queries)
- `documentTools.ts` — 1 document parsing tool (PDF/DOCX/TXT)
- `backgroundCommandTools.ts` — 3 background command tools
- `executionTools.ts` — 5 execution tools (JS, Python, shell, terminal, tests)
- `utilityTools.ts` — 24 utility tools (clipboard, notifications, system info, JSON query, env management)
- `imageProcessingTools.ts` — 4 image processing tools (OCR, screenshots, comparison)
- `httpClientTools.ts` — 3 HTTP client tools (GET/POST with SSRF protection)
- `vectorRagTools.ts` — 4 vector RAG tools (indexing, querying, clearing, web content)
- `textProcessingTools.ts` — 3 text processing tools (transform, extract, line operations)
- `uiGenerationTools.ts` — 3 UI generation tools (buttons, forms, charts, dashboards)
- `contextManagementTools.ts` — 7 auto-context management tools (summary, memory, search)
- `backupTools.ts` — 4 backup & restore tools (create, list, restore, delete)

---

## 📈 Recent Changes (v1.5.x)

### [1.5.23] - 2026-06-30 — `git_stash`, `git_blame` & `markdown_table_gen` Tools

**Added `json_query` and `env_update` tools, plus `@/` path aliases and ESLint fixes.**

- **`json_query`**: jq-style JSON field extraction with dot notation (`.key`, `.array[0]`, `.array[*]`), path validation, query depth limit (50), 10MB file cap
- **`env_update`**: Safe .env key-value management with key name validation, create/update logic, newline enforcement
- **Path Aliases**: `@/` → `src/` in `tsconfig.json` and `tsup.config.ts`
- **TypeScript Fix**: Resolved `TS2352` in `refactorCodeTools.ts` with intermediate `unknown` cast
- **ESLint Fixes**: Fixed unused parameter (`idx` → `_idx`) and redundant type assertions (`as string` on `segment`)

---

### [1.5.20] - 2026-06-29 — `grep_files` AST Mode Fallback Fix

**Fixed 3 failing AST mode tests caused by missing `regex` parameter in AST fallback path.**

When `mode: 'ast'` was used with `grep_files` and AST parsing failed, the fallback to regex mode crashed silently. The fix passes the pre-validated regex variable, enabling proper fallback behavior.

**Total**: 1 line changed in `src/tools/fileSystemTools.ts`, zero breaking changes.

---

### [1.5.19] - 2026-06-28 — Windows CRLF Line Ending Preservation Fix

**Fixed silent line ending corruption across 5 file-modifying tools on Windows.**

Tools that split file content into lines (`insert_at_line`, `delete_lines_in_file`, `text_transform` line-range mode, `line_operations`, `delete_lines`) now detect `\r\n` (CRLF) before splitting and preserve it on output. Files with Windows-style line endings are no longer silently converted to LF.

**Total**: 10 code changes across 3 files, zero breaking changes.

---

### [1.5.18] - 2026-06-27 — Cross-Platform Test Fix & AutoTracker FSM Logic Correction

**Fixed `grep_files` test path separator normalization and corrected AutoTracker FSM re-trigger logic.**

#### What Changed
- **Test Isolation**: Updated `tests/grep_files.test.ts` assertions to normalize Windows backslashes (`\`) to forward slashes (`/`) before comparison, ensuring reliable cross-platform test execution.
- **AutoTracker FSM Fix**: Removed incorrect state re-evaluation block in `src/autoTracker.ts` `checkTokenThreshold()`. The method now correctly returns `true` *only* during the initial IDLE → THRESHOLD_REACHED transition, preventing duplicate checkpoint prompts and redundant memory saves.

**Total**: 4 assertion blocks updated + 1 logic block removed, zero breaking changes.

---


### [1.5.14] - 2026-06-20 — Critical StateManager Read Path Fix

**`get_session_summary` now correctly re-reads from the CURRENT working directory on every call.**

Fixed `stateManager.ts` `getAllKeys()` to ALWAYS reload state from disk before returning keys (previously only loaded once at construction). This ensures reads see the latest data even if working directory changed mid-session via `change_directory`.

---

### [1.5.13] - 2026-06-20 — Jest moduleNameMapper Regex Fix

**Test suite now passes after fixing MODULE_NOT_FOUND errors for dynamically imported tool modules.**

Fixed all tool module dynamic import patterns in `jest.config.cjs` from two-dot (`'\\.\\.'`) to single-dot (`'\\./'`) regex matching. Removed conflicting ESM config file and added missing module mappings with a fallback catch-all rule.

---

### [1.5.12] - 2026-06-20 — Explicit Rollback Pattern

**All file-editing tools now automatically restore `.bak` backup on write failure.**

Four tools (`replace_text_in_file`, `insert_at_line`, `append_file`, `delete_lines_in_file`) wrap their `atomicWriteFile()` calls in try/catch:
1. On atomic write error → attempts `fs.copyFile(backupPath, fullPath)` to restore original
2. Logs `[FILE_EDIT] Atomic write failed — attempting rollback from <path>`
3. If rollback also fails, logs warning and returns original error

**Impact:** Protects against silent data corruption on disk-full, permission errors, or I/O failures during file modifications.

---

### 🔧 Major Refactoring (2026-06-13)

**Sync → Async Conversion:**
- Converted 200+ sync operations across 6 files to async/await
- Eliminates event loop starvation during high-load scenarios
- Files affected: `fileSystemTools.ts`, `documentTools.ts`, `stateManager.ts`, `contextManagementTools.ts`, `backupTools.ts`, `gitGithubTools.ts`

**Documentation Accuracy:**
- Rebuilt all documentation from scratch based on source code analysis
- Corrected tool counts (108 total across 20 categories)
- Verified configuration tables match Zod schema definitions exactly
- Updated architecture diagrams to reflect actual module structure

### 🔒 Security Enhancements (2026-06-04, 2026-06-16)

**grep_files Token Consumption Hardening:**
- Three-layer defense-in-depth: `max_content_length` (150 chars), `max_file_size` (100KB), `max_results` (20)
- Up to 99.6% fewer tokens for broad patterns across large projects
- Large build artifacts silently skipped before reading

**save_file Atomic Writes:**
- Replaced direct `writeFileSync` with temp file + rename pattern
- Size enforcement via Zod schema `.max()` and runtime validation
- Auto directory creation using recursive mkdir equivalent

### 🤖 Auto-Tracking Improvements (2026-06-15)

**Auto-Tracking Enabled by Default:**
- `autoTrackingEnabled` changed from `false` → `true`
- Configurable token threshold (default: 75%, range: 10–100%)
- Full auto-save implementation with msgpack storage since v1.5.7
- Integrated into promptPreprocessor Step 0.5 for checkpoint saving

### 🆕 New Tools Added (v1.5.23)

#### `git_stash` — Git Stash Management
**Purpose:** Manage git stashes: save, pop, drop, or list uncommitted changes.
**Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `action` | `'save' \| 'pop' \| 'drop' \| 'list'` | Yes | Stash action to perform |
| `message` | `string` | No (required for save) | Optional: Stash message |
**Features:** Full stash lifecycle management, lazy-loaded `simple-git` with proper type assertions, path validation via `validatePath` + `resolvePath`.

---

#### `git_blame` — Per-Line Commit History
**Purpose:** Get commit history for specific lines in a file.
**Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `file_path` | `string` | Yes | Path to the file to blame |
| `line_number` | `number` | No | Specific line number (if omitted, blames entire file) |
**Returns:** Array of `{ commitHash, author, timestamp, line, originalLine, summary }` objects.

---

#### `markdown_table_gen` — Markdown Table Generation
**Purpose:** Generate valid Markdown tables from arrays of objects with headers, alignment, and truncation.
**Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `data` | `Array<Record<string, unknown>>` | Yes | Array of objects to convert |
| `headers` | `string[]` | No | Custom header names (uses object keys if omitted) |
| `max_column_width` | `number` | No | Max width per column before truncation (default: 40) |
| `truncate_ellipsis` | `string` | No | Ellipsis character (default: `…`) |

---

#### `json_query` — JSON Field Extraction (jq Equivalent)
**Purpose:** Extract specific fields from JSON files using jq-style dot notation queries.
**Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `file_path` | `string` | Yes | Path to the JSON file |
| `query` | `string` | Yes | Query path (e.g., `".data.users[0].name"` or `".*.id"`) |
| `output_format` | `'json' \| 'text'` | No | Output format: json for structured output, text for raw value (default: text) |
**Features:** Supports `.key`, `.key.subkey`, `.array[0]`, `.array[*]` (wildcard) syntax. Path validation (no directory traversal). Query depth limit: 50 segments. File size cap: 10MB. Implements `safeJsonQuery()` helper with comprehensive error handling.

---

#### `env_update` — Environment Variable Management
**Purpose:** Add or update key-value pairs in `.env` files.
**Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `file_path` | `string` | Yes | Path to the .env file |
| `key` | `string` | Yes | Environment variable key (alphanumeric + underscores only) |
| `value` | `string` | Yes | Environment variable value |
| `ensure_newline` | `boolean` | No | Ensure the file ends with a newline (default: true) |
**Features:** Key validation (must start with letter/underscore). Creates key if missing, updates if present. Ensures file ends with newline. File creation if `.env` doesn't exist.

---

#### `analyze_project` — Static Analysis
**Purpose:** Run TypeScript diagnostics, ESLint, circular dependency checks, and import analysis.
**Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `categories` | `'typecheck' \| 'circular' \| 'eslint' \| 'config' \| 'imports'` | No | Analysis categories to run (default: all) |
| `max_imports_warning` | `number` | No | Max imports per file before warning (default: 20) |

---

#### `file_diff` — Side-by-Side Comparison
**Purpose:** Compare two files and return a unified diff with +/- markers and line numbers.

---

#### `directory_tree` — Directory Visualization
**Purpose:** Visualize the directory structure of a path in a tree-like format. Supports max depth, optional file sizes, and automatic exclusion of large directories.

---

#### `grep_files` — Enhanced Search
**Purpose:** Search files with regex or AST mode. Includes three-layer token consumption controls (`max_content_length`, `max_file_size`, `max_results`). Fixed AST fallback path in v1.5.20.

---

#### `run_tests` — Test Execution
**Purpose:** Execute test suites (Jest, PyTest, Go test) with timeout protection.

---

#### `rag_web_content` — Web Content RAG
**Purpose:** Fetch content from a URL and use RAG to find and return only the text chunks most relevant to a specific query.

---

#### `find_replace_all` — Multi-File Search & Replace
**Purpose:** Search and replace text across multiple files in a directory using regex. Supports dry-run mode and safety confirmations. Added in v1.5.20.

---

## 🔐 Security Posture

### Multi-Layer Defense Strategy

1. **Input Validation** — Zod schemas validate all user inputs before processing
2. **Path Validation** — All file paths pass through `validatePath()` with base path enforcement
3. **Command Sanitization** — Shell commands undergo multi-layer sanitization blocking dangerous patterns
4. **Category Enforcement** — Tools gated by configuration (execution tools disabled by default)
5. **Code Sandboxing** — JS/Python execution blocks eval, exec, child_process, network access

### Threat Mitigation Matrix

| Threat | Risk Level | Mitigation | Status |
|--------|------------|------------|--------|
| Directory Traversal | High | `validatePath()` with base path enforcement | ✅ Active |
| Command Injection | Critical | `sanitizeCommand()` blocks dangerous patterns | ✅ Active |
| ReDoS Attacks | Medium | `isSafeRegex()` treats unsafe patterns as literals | ✅ Active |
| SSRF (HTTP Client) | High | URL protocol validation + private IP blocking | ✅ Active |
| Token Explosion | High | Three-layer controls in grep_files tool | ✅ Active |
| Large File DoS | Medium | Size limits on file operations (10MB writes, 50KB fetches) | ✅ Active |

---

## ⚡ Performance Characteristics

### Async Operations

All I/O operations use async/await to avoid blocking:
- **File system**: `fs.promises` for non-blocking reads/writes
- **Database**: Node.js SQLite with async APIs
- **Browser automation**: Puppeteer with connection pooling and auto-retry
- **HTTP requests**: Native fetch with timeout protection (30s default)

### Caching Strategy

| Cache | TTL | Max Entries | Purpose |
|-------|-----|-------------|---------|
| Fuzzy Search | 60s | 100 | File name similarity results with Levenshtein scoring |
| Web Requests | 30s | 50 | HTTP responses for web research tools |

### Lazy Loading

Heavy dependencies loaded on first use to minimize startup time:
- **Puppeteer** — Browser automation (50MB+)
- **Tesseract.js** — OCR engine
- **SQLite** — Database engine (Node 23+)
- **pdf-parse / mammoth** — Document parsing

---

## 🧪 Development Status

### Test Coverage

- **19 tests** — all passing ✅ (including 3 AST mode tests fixed in v1.5.20)
- Type checking clean: `npx tsc --noEmit` with zero errors
- Linting passes: `npm run lint` with zero errors

### Build Configuration

| Tool | Version | Purpose |
|------|---------|---------|
| TypeScript | ^5.9.3 | Strict mode type checking (zero errors) |
| tsup | ^8.3.5 | Bundler for production builds (ESM + CJS) |
| Jest | ^30.0.0 | Test framework with ESM mocking |
| ESLint | ^9.15.0 | Code quality enforcement |
| `@/` Path Aliases | Configured | Simplified import resolution (`src/*` → `@/*`) |

### Dependency Security

- **glob**: Upgraded to v13.0.6 (CVE-2025-64756 patched)
- **uuid**: Upgraded to v11.0.4 (cryptographically secure implementation)
- Clean `npm audit` with 0 vulnerabilities, 0 warnings ✅

---

## 📚 Documentation Status

All documentation has been reconstructed based on actual source code analysis:

| File | Status | Notes |
|------|--------|-------|
| `README.md` | ✅ Rebuilt | Accurate tool counts, configuration tables derived from Zod schema |
| `ARCHITECTURE.md` | ✅ Rebuilt | Correct system overview diagram (16 modules), verified data flows |
| `TOOLS_REFERENCE.md` | ✅ Rebuilt | All 110 tools documented with parameter tables matching implementations |
| `DOCUMENTATION.md` | ✅ Rebuilt | Cleaned up duplicate sections, verified version history against source code |
| `CHANGELOG.md` | ✅ Updated | Accurate release dates and tool count corrections |
| `CONTRIBUTING.md` | ✅ Created | Development workflow, adding new tools guidelines |
| `SAFE_EDIT_GUIDE.md` | ✅ Created | Backup-first strategy for safe file editing |
| `SECURITY.md` | ✅ Rebuilt | Threat model, security controls, incident response procedures |

---

## 🚀 Next Steps

### For Contributors
1. Review CONTRIBUTING.md for development workflow guidelines
2. Follow the Safe Edit Guide when modifying files
3. Ensure all tests pass before submitting PRs (`npm test`)

### For Users
1. Enable tool categories in LM Studio plugin settings as needed
2. Review SECURITY.md to understand default restrictions and configuration options
3. Use TOOLS_REFERENCE.md for complete parameter documentation for each tool

---

## 📝 Notes

This summary is based on actual source code analysis performed on 2026-06-30. All tool counts, feature descriptions, and security controls reflect the current implementation in version 1.5.x.

For questions or issues, please refer to the individual documentation files linked above or contact the maintainers through appropriate channels.
